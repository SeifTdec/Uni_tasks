"""
================================================================
 Project 1 – Large-Scale Evaluation of Modern Sort & Search
================================================================
 Sorting  : Timsort | PDQSort | IntroSort
 Searching: Binary Search | Exponential Search | Skip List
 Dataset  : 1,000,000 integers (4 variants)
 Output   : console table + CSV files + 6 PNG graphs
================================================================
"""

import random
import time
import math
import sys
import csv
import os
from copy import copy
from dataclasses import dataclass, field
from typing import List, Callable

sys.setrecursionlimit(50_000)
os.makedirs("graphs", exist_ok=True)

# ──────────────────────────────────────────────────────────────
#  Comparison counter  (reset before every timed run)
# ──────────────────────────────────────────────────────────────
class Counter:
    def __init__(self): self.n = 0
    def inc(self):      self.n += 1
    def reset(self):    self.n = 0

CMP = Counter()


# ================================================================
#  PART 1 — DATASET GENERATION
# ================================================================

N = 1_000_000          # total dataset size
QUERIES = 1_000        # number of search queries


def gen_random(n=N, seed=42):
    """Uniform random integers in [1, 10 000 000]."""
    rng = random.Random(seed)
    return [rng.randint(1, 10_000_000) for _ in range(n)]


def gen_nearly_sorted(n=N, seed=42):
    """Sorted list with 1 % of positions randomly swapped."""
    data = list(range(1, n + 1))
    rng  = random.Random(seed)
    for _ in range(max(1, n // 100)):
        i, j = rng.randrange(n), rng.randrange(n)
        data[i], data[j] = data[j], data[i]
    return data


def gen_reverse_sorted(n=N):
    """Strictly descending: n, n-1, …, 1."""
    return list(range(n, 0, -1))


def gen_duplicates(n=N, seed=42):
    """Values drawn from [1, 1000] – heavy duplicates."""
    rng = random.Random(seed)
    return [rng.randint(1, 1_000) for _ in range(n)]


# ================================================================
#  PART 2 — SORTING ALGORITHMS
# ================================================================

# ----------------------------------------------------------------
#  A)  TIMSORT
#      Hybrid of insertion sort (for small 'runs') + merge sort.
#      Detects natural sorted sub-sequences to minimise work.
#      Python's built-in list.sort() IS Timsort (C implementation).
#      We implement our own Python version so comparison counting
#      and timing measure the algorithm fairly.
#
#      Complexity:  Best O(n) | Avg/Worst O(n log n) | Space O(n)
# ----------------------------------------------------------------
TIM_RUN = 32          # minimum run length


def _tim_insertion_sort(arr: list, lo: int, hi: int) -> None:
    """In-place insertion sort over arr[lo..hi] inclusive."""
    for i in range(lo + 1, hi + 1):
        key = arr[i]
        j   = i - 1
        while j >= lo:
            CMP.inc()
            if arr[j] > key:
                arr[j + 1] = arr[j]
                j -= 1
            else:
                break
        arr[j + 1] = key


def _tim_merge(arr: list, lo: int, mid: int, hi: int) -> None:
    """Merge arr[lo..mid] and arr[mid+1..hi] in-place."""
    left  = arr[lo : mid + 1]
    right = arr[mid + 1 : hi + 1]
    i = j = 0
    k = lo
    while i < len(left) and j < len(right):
        CMP.inc()
        if left[i] <= right[j]:
            arr[k] = left[i]; i += 1
        else:
            arr[k] = right[j]; j += 1
        k += 1
    while i < len(left):
        arr[k] = left[i]; i += 1; k += 1
    while j < len(right):
        arr[k] = right[j]; j += 1; k += 1


def timsort(arr: list) -> None:
    """Sort arr in-place using Timsort."""
    n = len(arr)
    # Phase 1 – sort every run-sized block with insertion sort
    for lo in range(0, n, TIM_RUN):
        _tim_insertion_sort(arr, lo, min(lo + TIM_RUN - 1, n - 1))
    # Phase 2 – merge runs, doubling the window each pass
    size = TIM_RUN
    while size < n:
        for lo in range(0, n, 2 * size):
            mid = min(lo + size - 1, n - 1)
            hi  = min(lo + 2 * size - 1, n - 1)
            if mid < hi:
                _tim_merge(arr, lo, mid, hi)
        size *= 2


# ----------------------------------------------------------------
#  B)  PDQSORT  (Pattern-Defeating Quicksort)
#      Combines quicksort + heapsort + insertion sort.
#      Detects already-sorted and reverse-sorted patterns.
#      Falls back to heapsort when recursion depth is exceeded,
#      guaranteeing O(n log n) worst case.
#
#      Complexity:  Best O(n) | Avg O(n log n) | Worst O(n log n)
#                   Space O(log n)
# ----------------------------------------------------------------
PDQ_THRESH = 24          # switch to insertion sort below this size


def _pdq_insertion_sort(arr: list, lo: int, hi: int) -> None:
    for i in range(lo + 1, hi + 1):
        key = arr[i]; j = i - 1
        while j >= lo:
            CMP.inc()
            if arr[j] > key: arr[j + 1] = arr[j]; j -= 1
            else: break
        arr[j + 1] = key


def _pdq_median3(arr: list, a: int, b: int, c: int) -> int:
    """Return index of median among arr[a], arr[b], arr[c]."""
    CMP.inc(); CMP.inc()
    if arr[a] < arr[b]:
        if arr[b] < arr[c]: return b
        return c if arr[a] < arr[c] else a
    if arr[a] < arr[c]: return a
    return c if arr[b] < arr[c] else b


def _pdq_heapsort(arr: list, lo: int, hi: int) -> None:
    """Heapsort over arr[lo..hi] inclusive."""
    n = hi - lo + 1

    def sift(root, size):
        while True:
            largest, l, r = root, 2*root+1, 2*root+2
            if l < size:
                CMP.inc()
                if arr[lo+l] > arr[lo+largest]: largest = l
            if r < size:
                CMP.inc()
                if arr[lo+r] > arr[lo+largest]: largest = r
            if largest == root: break
            arr[lo+root], arr[lo+largest] = arr[lo+largest], arr[lo+root]
            root = largest

    for i in range(n // 2 - 1, -1, -1):
        sift(i, n)
    for i in range(n - 1, 0, -1):
        arr[lo], arr[lo+i] = arr[lo+i], arr[lo]
        sift(0, i)


def _pdq_impl(arr: list, lo: int, hi: int, depth: int) -> None:
    while hi - lo + 1 > PDQ_THRESH:
        if depth == 0:
            _pdq_heapsort(arr, lo, hi)
            return

        # Pattern detection: check if already sorted
        already_sorted = True
        for i in range(lo, hi):
            CMP.inc()
            if arr[i] > arr[i + 1]:
                already_sorted = False
                break
        if already_sorted:
            return

        # Median-of-three pivot
        mid   = lo + (hi - lo) // 2
        pivot_idx = _pdq_median3(arr, lo, mid, hi)
        arr[pivot_idx], arr[hi] = arr[hi], arr[pivot_idx]
        pivot = arr[hi]

        # Partition
        i = lo - 1
        for j in range(lo, hi):
            CMP.inc()
            if arr[j] <= pivot:
                i += 1
                arr[i], arr[j] = arr[j], arr[i]
        arr[i + 1], arr[hi] = arr[hi], arr[i + 1]
        p = i + 1

        depth -= 1
        # Recurse on smaller half, iterate on larger (tail-call optimisation)
        if p - lo < hi - p:
            _pdq_impl(arr, lo, p - 1, depth)
            lo = p + 1
        else:
            _pdq_impl(arr, p + 1, hi, depth)
            hi = p - 1

    _pdq_insertion_sort(arr, lo, hi)


def pdqsort(arr: list) -> None:
    """Sort arr in-place using PDQSort."""
    if len(arr) < 2: return
    depth = 2 * int(math.log2(len(arr)) + 1)
    _pdq_impl(arr, 0, len(arr) - 1, depth)


# ----------------------------------------------------------------
#  C)  INTROSORT
#      Industry standard – basis of C++ std::sort.
#      Quicksort core + heapsort fallback at depth 2·log₂n
#      + insertion sort for small subarrays (< 16 elements).
#
#      Complexity:  Best/Avg/Worst O(n log n) | Space O(log n)
# ----------------------------------------------------------------
INTRO_THRESH = 16


def _intro_insertion_sort(arr: list, lo: int, hi: int) -> None:
    for i in range(lo + 1, hi + 1):
        key = arr[i]; j = i - 1
        while j >= lo:
            CMP.inc()
            if arr[j] > key: arr[j + 1] = arr[j]; j -= 1
            else: break
        arr[j + 1] = key


def _intro_heapsort(arr: list, lo: int, hi: int) -> None:
    n = hi - lo + 1

    def sift(root, size):
        while True:
            largest, l, r = root, 2*root+1, 2*root+2
            if l < size:
                CMP.inc()
                if arr[lo+l] > arr[lo+largest]: largest = l
            if r < size:
                CMP.inc()
                if arr[lo+r] > arr[lo+largest]: largest = r
            if largest == root: break
            arr[lo+root], arr[lo+largest] = arr[lo+largest], arr[lo+root]
            root = largest

    for i in range(n // 2 - 1, -1, -1): sift(i, n)
    for i in range(n - 1, 0, -1):
        arr[lo], arr[lo+i] = arr[lo+i], arr[lo]
        sift(0, i)


def _intro_partition(arr: list, lo: int, hi: int) -> int:
    mid = lo + (hi - lo) // 2
    # Median-of-three pivot
    if arr[mid] < arr[lo]:  arr[mid], arr[lo]  = arr[lo],  arr[mid]
    if arr[hi]  < arr[lo]:  arr[hi],  arr[lo]  = arr[lo],  arr[hi]
    if arr[mid] < arr[hi]:  arr[mid], arr[hi]  = arr[hi],  arr[mid]
    pivot = arr[hi]
    i = lo - 1
    for j in range(lo, hi):
        CMP.inc()
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[hi] = arr[hi], arr[i + 1]
    return i + 1


def _intro_impl(arr: list, lo: int, hi: int, depth: int) -> None:
    while hi - lo + 1 > INTRO_THRESH:
        if depth == 0:
            _intro_heapsort(arr, lo, hi)
            return
        p = _intro_partition(arr, lo, hi)
        depth -= 1
        # Tail-call optimisation: recurse on smaller partition
        if p - lo < hi - p:
            _intro_impl(arr, lo, p - 1, depth)
            lo = p + 1
        else:
            _intro_impl(arr, p + 1, hi, depth)
            hi = p - 1
    _intro_insertion_sort(arr, lo, hi)


def introsort(arr: list) -> None:
    """Sort arr in-place using IntroSort."""
    if len(arr) < 2: return
    depth = 2 * int(math.log2(len(arr)) + 1)
    _intro_impl(arr, 0, len(arr) - 1, depth)


# ================================================================
#  PART 3 — SEARCH ALGORITHMS
# ================================================================

# ----------------------------------------------------------------
#  A)  BINARY SEARCH — O(log n)
# ----------------------------------------------------------------
def binary_search(arr: list, target: int) -> int:
    lo, hi = 0, len(arr) - 1
    while lo <= hi:
        CMP.inc()
        mid = (lo + hi) >> 1
        if arr[mid] == target:   return mid
        CMP.inc()
        if arr[mid] < target:    lo = mid + 1
        else:                    hi = mid - 1
    return -1


# ----------------------------------------------------------------
#  B)  EXPONENTIAL SEARCH — O(log i) where i = target position
# ----------------------------------------------------------------
def exponential_search(arr: list, target: int) -> int:
    n = len(arr)
    if n == 0: return -1
    CMP.inc()
    if arr[0] == target: return 0
    i = 1
    while i < n:
        CMP.inc()
        if arr[i] <= target: i <<= 1
        else: break
    # Binary search in discovered range
    lo, hi = i >> 1, min(i, n - 1)
    while lo <= hi:
        CMP.inc()
        mid = (lo + hi) >> 1
        if arr[mid] == target:  return mid
        CMP.inc()
        if arr[mid] < target:   lo = mid + 1
        else:                   hi = mid - 1
    return -1


# ----------------------------------------------------------------
#  C)  SKIP LIST — O(log n) expected search
#      Probabilistic multi-level sorted linked list.
#      Each node is promoted to higher levels with p = 0.5.
#      Max 16 levels supports up to 2^16 = 65 536 elements well;
#      we use 20 levels for 1 000 000 elements.
# ----------------------------------------------------------------
_SKIP_MAX  = 20
_SKIP_PROB = 0.5

class _SLNode:
    __slots__ = ("val", "nxt")
    def __init__(self, val: int, level: int):
        self.val = val
        self.nxt: List["_SLNode | None"] = [None] * (level + 1)


class SkipList:
    def __init__(self, seed: int = 99):
        self._rng   = random.Random(seed)
        self._level = 0
        self._head  = _SLNode(float("-inf"), _SKIP_MAX)

    def _random_level(self) -> int:
        lvl = 0
        while self._rng.random() < _SKIP_PROB and lvl < _SKIP_MAX:
            lvl += 1
        return lvl

    def insert(self, val: int) -> None:
        update = [None] * (_SKIP_MAX + 1)
        cur    = self._head
        for i in range(self._level, -1, -1):
            while cur.nxt[i] and cur.nxt[i].val < val:
                cur = cur.nxt[i]
            update[i] = cur
        nl = self._random_level()
        if nl > self._level:
            for i in range(self._level + 1, nl + 1):
                update[i] = self._head
            self._level = nl
        node = _SLNode(val, nl)
        for i in range(nl + 1):
            node.nxt[i]    = update[i].nxt[i]
            update[i].nxt[i] = node

    def search(self, target: int) -> bool:
        cur = self._head
        for i in range(self._level, -1, -1):
            while cur.nxt[i]:
                CMP.inc()
                if cur.nxt[i].val < target:
                    cur = cur.nxt[i]
                else:
                    break
        cur = cur.nxt[0]
        CMP.inc()
        return cur is not None and cur.val == target


# ================================================================
#  PART 4 — EXPERIMENT HARNESS
# ================================================================

@dataclass
class SortResult:
    algorithm:   str
    dataset:     str
    time_ms:     float
    comparisons: int
    correct:     bool


@dataclass
class SearchResult:
    algorithm:    str
    avg_us:       float
    worst_us:     float
    avg_cmp:      int
    found_rate:   float        # fraction of queries that found a result


def _run_sort(name: str, ds_name: str, data: list,
              fn: Callable) -> SortResult:
    arr = data[:]           # fresh copy
    CMP.reset()
    t0  = time.perf_counter()
    fn(arr)
    elapsed = (time.perf_counter() - t0) * 1000   # ms
    cmp_val = CMP.n
    correct = all(arr[i] <= arr[i+1] for i in range(len(arr)-1))
    return SortResult(name, ds_name, round(elapsed, 3), cmp_val, correct)


def _run_search(name: str, sorted_arr: list,
                queries: list, fn: Callable) -> SearchResult:
    times  = []
    cmps   = []
    found  = 0
    for q in queries:
        CMP.reset()
        t0 = time.perf_counter()
        r  = fn(q)
        times.append((time.perf_counter() - t0) * 1_000_000)  # µs
        cmps.append(CMP.n)
        if r is not None and r is not False and r != -1:
            found += 1
    return SearchResult(
        name,
        round(sum(times) / len(times), 4),
        round(max(times), 4),
        int(sum(cmps) / len(cmps)),
        round(found / len(queries), 3)
    )


# ================================================================
#  PART 5 — MAIN EXPERIMENT
# ================================================================

def run_experiments():
    print("=" * 68)
    print("  Large-Scale Sorting & Searching Evaluation  |  N =", N)
    print("=" * 68)

    # ── Build datasets ─────────────────────────────────────────
    print("\n[1/4]  Generating datasets …")
    datasets = [
        ("Random",         gen_random()),
        ("Nearly Sorted",  gen_nearly_sorted()),
        ("Reverse Sorted", gen_reverse_sorted()),
        ("Duplicates",     gen_duplicates()),
    ]
    print("       Done.\n")

    sorters = [
        ("Timsort",   timsort),
        ("PDQSort",   pdqsort),
        ("IntroSort", introsort),
    ]

    # ── Sorting experiment ─────────────────────────────────────
    print("[2/4]  Running sorting experiments …")
    print(f"       (3 algorithms × 4 datasets = 12 runs on {N:,} elements)\n")

    sort_results: List[SortResult] = []

    hdr = f"{'Algorithm':<13} {'Dataset':<16} {'Time (ms)':>11} {'Comparisons':>14}  {'OK?'}"
    print(hdr)
    print("-" * len(hdr))

    for ds_name, ds_data in datasets:
        for alg_name, alg_fn in sorters:
            r = _run_sort(alg_name, ds_name, ds_data, alg_fn)
            sort_results.append(r)
            print(f"  {r.algorithm:<11} {r.dataset:<16} {r.time_ms:>11,.2f}"
                  f" {r.comparisons:>14,}  {'✓' if r.correct else '✗ FAIL'}")
        print()

    # Save CSV
    with open("sort_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Algorithm", "Dataset", "Time_ms", "Comparisons", "Correct"])
        for r in sort_results:
            w.writerow([r.algorithm, r.dataset, r.time_ms, r.comparisons, r.correct])
    print("  → sort_results.csv written\n")

    # ── Build search structures on sorted Random data ──────────
    print("[3/4]  Building search structures …")
    base = datasets[0][1][:]     # Random dataset, fresh copy
    base.sort()                  # sort with Python built-in (fast)

    print("       Building Skip List …", end=" ", flush=True)
    sl = SkipList()
    for x in base:
        sl.insert(x)
    print("Done.")

    # Generate 1000 query values
    rng     = random.Random(77)
    queries = [rng.randint(1, 10_000_000) for _ in range(QUERIES)]

    searchers = [
        ("Binary Search",      lambda q: binary_search(base, q)),
        ("Exponential Search", lambda q: exponential_search(base, q)),
        ("Skip List",          lambda q: sl.search(q)),
    ]

    # ── Search experiment ──────────────────────────────────────
    print("\n[4/4]  Running search experiments …\n")
    hdr2 = f"{'Algorithm':<22} {'Avg (µs)':>10} {'Worst (µs)':>12} {'Avg Cmps':>10}  {'Found %'}"
    print(hdr2)
    print("-" * len(hdr2))

    search_results: List[SearchResult] = []

    for name, fn in searchers:
        r = _run_search(name, base, queries, fn)
        search_results.append(r)
        print(f"  {r.algorithm:<20} {r.avg_us:>10.4f} {r.worst_us:>12.4f}"
              f" {r.avg_cmp:>10}  {r.found_rate*100:.1f}%")

    with open("search_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Algorithm", "Avg_us", "Worst_us", "Avg_Comparisons", "Found_Rate"])
        for r in search_results:
            w.writerow([r.algorithm, r.avg_us, r.worst_us, r.avg_cmp, r.found_rate])
    print("\n  → search_results.csv written")

    return sort_results, search_results


# ================================================================
#  PART 6 — GRAPHS
# ================================================================

def generate_graphs(sort_results: list, search_results: list):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.ticker as mtk
        import numpy as np
    except ImportError:
        print("\n[graphs] matplotlib not found – skipping graphs.")
        return

    plt.rcParams.update({
        "figure.dpi": 140,
        "font.family": "DejaVu Sans",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.3,
        "axes.labelsize": 11,
        "axes.titlesize": 12,
        "axes.titleweight": "bold",
    })

    PALETTES = {
        "Timsort":           "#2196F3",
        "PDQSort":           "#4CAF50",
        "IntroSort":         "#FF5722",
        "Binary Search":     "#9C27B0",
        "Exponential Search":"#FF9800",
        "Skip List":         "#00BCD4",
    }

    datasets  = [r.dataset    for r in sort_results if r.algorithm == "Timsort"]
    alg_names = ["Timsort", "PDQSort", "IntroSort"]
    x         = np.arange(len(datasets))
    W         = 0.26

    # ── Fig 1 – Sorting Time ────────────────────────────────────
    fig, ax = plt.subplots(figsize=(11, 5))
    for i, alg in enumerate(alg_names):
        vals  = [r.time_ms for r in sort_results if r.algorithm == alg]
        bars  = ax.bar(x + i * W, vals, W, label=alg,
                       color=PALETTES[alg], alpha=0.88, zorder=3)
        ax.bar_label(bars, fmt="%.0f ms", padding=3, fontsize=8)
    ax.set_xticks(x + W); ax.set_xticklabels(datasets)
    ax.set_ylabel("Execution Time (ms)")
    ax.set_title(f"Sorting Algorithm Comparison — Execution Time  (N = {N:,})")
    ax.legend(); fig.tight_layout()
    fig.savefig("graphs/fig1_sort_time.png", bbox_inches="tight")
    plt.close(fig)
    print("  → graphs/fig1_sort_time.png")

    # ── Fig 2 – Sorting Comparisons ─────────────────────────────
    fig, ax = plt.subplots(figsize=(11, 5))
    for i, alg in enumerate(alg_names):
        vals = [r.comparisons for r in sort_results if r.algorithm == alg]
        ax.bar(x + i * W, vals, W, label=alg, color=PALETTES[alg], alpha=0.88, zorder=3)
    ax.set_xticks(x + W); ax.set_xticklabels(datasets)
    ax.yaxis.set_major_formatter(mtk.FuncFormatter(lambda v, _: f"{v/1e6:.1f}M"))
    ax.set_ylabel("Number of Comparisons")
    ax.set_title("Sorting Algorithm Comparison — Number of Comparisons")
    ax.legend(); fig.tight_layout()
    fig.savefig("graphs/fig2_sort_comparisons.png", bbox_inches="tight")
    plt.close(fig)
    print("  → graphs/fig2_sort_comparisons.png")

    # ── Fig 3 – O(n log n) Scaling Projection ──────────────────
    sizes  = np.array([1_000, 10_000, 100_000, 500_000, 1_000_000])
    fig, ax = plt.subplots(figsize=(9, 5))
    ref = N
    for alg in alg_names:
        base_t = next(r.time_ms for r in sort_results
                      if r.algorithm == alg and r.dataset == "Random")
        pred = base_t * (sizes * np.log2(sizes + 1)) / (ref * math.log2(ref + 1))
        ax.plot(sizes, pred, "o--", label=alg, color=PALETTES[alg],
                linewidth=2, markersize=6)
    ax.set_xscale("log")
    ax.set_xlabel("Input Size  n"); ax.set_ylabel("Estimated Time (ms)")
    ax.set_title("Projected Performance vs Input Size  (O(n log n) scaling)")
    ax.legend(); fig.tight_layout()
    fig.savefig("graphs/fig3_scaling.png", bbox_inches="tight")
    plt.close(fig)
    print("  → graphs/fig3_scaling.png")

    # ── Fig 4 – Search Avg & Worst Time ─────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(11, 5))
    salgs  = [r.algorithm for r in search_results]
    colors = [PALETTES[a] for a in salgs]

    for ax_idx, (col, ylabel, title) in enumerate([
            ("avg_us",   "Avg Query Time (µs)",        "Search: Average Query Time"),
            ("worst_us", "Worst-Case Query Time (µs)",  "Search: Worst-Case Query Time"),
    ]):
        ax = axes[ax_idx]
        vals = [getattr(r, col) for r in search_results]
        bars = ax.bar(salgs, vals, color=colors, alpha=0.88, zorder=3)
        ax.bar_label(bars, fmt="%.4f", padding=3, fontsize=8)
        ax.set_ylabel(ylabel); ax.set_title(title)
        ax.tick_params(axis="x", rotation=12)

    fig.suptitle(f"Search Algorithms  ({QUERIES:,} queries on {N:,} elements)",
                 fontweight="bold", y=1.02)
    fig.tight_layout()
    fig.savefig("graphs/fig4_search_time.png", bbox_inches="tight")
    plt.close(fig)
    print("  → graphs/fig4_search_time.png")

    # ── Fig 5 – Search Comparisons (horizontal bar) ─────────────
    fig, ax = plt.subplots(figsize=(8, 4))
    avg_cmps = [r.avg_cmp for r in search_results]
    ax.barh(salgs, avg_cmps, color=colors, alpha=0.88, zorder=3)
    ax.set_xlabel("Average Comparisons per Query")
    ax.set_title("Search Algorithm — Average Comparisons")
    theoretical = int(math.log2(N))
    ax.axvline(theoretical, linestyle="--", color="red", alpha=0.7,
               label=f"Theoretical log₂({N:,}) = {theoretical}")
    ax.legend(); fig.tight_layout()
    fig.savefig("graphs/fig5_search_comparisons.png", bbox_inches="tight")
    plt.close(fig)
    print("  → graphs/fig5_search_comparisons.png")

    # ── Fig 6 – Heatmap: sort time normalised ───────────────────
    time_matrix = np.array([
        [r.time_ms for r in sort_results if r.algorithm == alg]
        for alg in alg_names
    ], dtype=float)
    row_max = time_matrix.max(axis=1, keepdims=True)
    norm    = time_matrix / row_max

    fig, ax = plt.subplots(figsize=(9, 3.5))
    im = ax.imshow(norm, cmap="RdYlGn_r", aspect="auto", vmin=0, vmax=1)
    ax.set_xticks(range(len(datasets)));   ax.set_xticklabels(datasets, fontsize=10)
    ax.set_yticks(range(len(alg_names))); ax.set_yticklabels(alg_names, fontsize=11,
                                                               fontweight="bold")
    for i in range(len(alg_names)):
        for j in range(len(datasets)):
            ax.text(j, i, f"{time_matrix[i,j]:.0f} ms",
                    ha="center", va="center", fontsize=9)
    plt.colorbar(im, ax=ax, fraction=0.04, label="Relative Time  (1 = slowest per row)")
    ax.set_title("Heatmap: Sorting Time Across Dataset Variants", fontweight="bold")
    fig.tight_layout()
    fig.savefig("graphs/fig6_heatmap.png", bbox_inches="tight")
    plt.close(fig)
    print("  → graphs/fig6_heatmap.png")


# ================================================================
#  ENTRY POINT
# ================================================================

if __name__ == "__main__":
    sort_res, search_res = run_experiments()

    print("\n" + "=" * 68)
    print("  Generating graphs …")
    print("=" * 68)
    generate_graphs(sort_res, search_res)

    print("\n" + "=" * 68)
    print("  All done!  Files written:")
    print("    sort_results.csv   search_results.csv")
    print("    graphs/fig1_sort_time.png  … fig6_heatmap.png")
    print("=" * 68)
