/**
 * ================================================================
 * Project 1: Large-Scale Evaluation of Modern Sorting & Searching
 * ================================================================
 * Sorting  : Timsort | PDQSort | IntroSort
 * Searching: Binary Search | Exponential Search | Skip List
 * Dataset  : 1,000,000 elements (4 variants)
 * ================================================================
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <random>
#include <cmath>
#include <climits>
#include <fstream>
#include <string>
#include <iomanip>
#include <functional>

using namespace std;
using namespace std::chrono;

// ================================================================
//  Global comparison counter (reset before each run)
// ================================================================
long long g_comparisons = 0;

// ================================================================
//  PART 1 — DATASET GENERATION
// ================================================================

/** 1a. Uniform random integers [1, 10,000,000] */
vector<int> generateRandom(int n, unsigned seed = 42) {
    vector<int> data(n);
    mt19937 rng(seed);
    uniform_int_distribution<int> dist(1, 10'000'000);
    for (auto& x : data) x = dist(rng);
    return data;
}

/** 1b. Nearly sorted: sorted array with ~1% random swaps */
vector<int> generateNearlySorted(int n, unsigned seed = 42) {
    vector<int> data(n);
    iota(data.begin(), data.end(), 1);          // 1,2,...,n
    mt19937 rng(seed);
    uniform_int_distribution<int> dist(0, n - 1);
    int swaps = max(1, n / 100);
    for (int i = 0; i < swaps; i++)
        swap(data[dist(rng)], data[dist(rng)]);
    return data;
}

/** 1c. Reverse sorted: n, n-1, ..., 1 */
vector<int> generateReverseSorted(int n) {
    vector<int> data(n);
    for (int i = 0; i < n; i++) data[i] = n - i;
    return data;
}

/** 1d. Heavy duplicates: values drawn from [1, 1000] */
vector<int> generateWithDuplicates(int n, unsigned seed = 42) {
    vector<int> data(n);
    mt19937 rng(seed);
    uniform_int_distribution<int> dist(1, 1000);
    for (auto& x : data) x = dist(rng);
    return data;
}

// ================================================================
//  PART 2 — SORTING ALGORITHMS
// ================================================================

// ----------------------------------------------------------------
//  A) TIMSORT
//     Hybrid of merge sort + insertion sort.
//     Identifies natural "runs" of already-sorted data.
//     Best: O(n)  |  Avg & Worst: O(n log n)
// ----------------------------------------------------------------
static const int TIM_RUN = 32;   // minimum run size

void tim_insertionSort(vector<int>& arr, int left, int right) {
    for (int i = left + 1; i <= right; i++) {
        int temp = arr[i];
        int j    = i - 1;
        while (j >= left) {
            ++g_comparisons;
            if (arr[j] > temp) { arr[j + 1] = arr[j]; --j; }
            else break;
        }
        arr[j + 1] = temp;
    }
}

void tim_merge(vector<int>& arr, int l, int m, int r) {
    vector<int> left(arr.begin() + l, arr.begin() + m + 1);
    vector<int> right(arr.begin() + m + 1, arr.begin() + r + 1);
    int i = 0, j = 0, k = l;
    while (i < (int)left.size() && j < (int)right.size()) {
        ++g_comparisons;
        arr[k++] = (left[i] <= right[j]) ? left[i++] : right[j++];
    }
    while (i < (int)left.size())  arr[k++] = left[i++];
    while (j < (int)right.size()) arr[k++] = right[j++];
}

void timSort(vector<int>& arr) {
    int n = (int)arr.size();
    // Phase 1: sort every RUN-sized block with insertion sort
    for (int i = 0; i < n; i += TIM_RUN)
        tim_insertionSort(arr, i, min(i + TIM_RUN - 1, n - 1));
    // Phase 2: merge runs pairwise, doubling size each pass
    for (int size = TIM_RUN; size < n; size <<= 1) {
        for (int left = 0; left < n; left += 2 * size) {
            int mid   = min(left + size - 1, n - 1);
            int right = min(left + 2 * size - 1, n - 1);
            if (mid < right)
                tim_merge(arr, left, mid, right);
        }
    }
}

// ----------------------------------------------------------------
//  B) PDQSORT (Pattern-Defeating Quicksort)
//     Detects already-sorted, reverse-sorted, and many-duplicate
//     patterns to switch strategies.
//     Uses: insertion sort (small) | heapsort (depth exceeded)
//     Best: O(n)  |  Avg: O(n log n)  |  Worst: O(n log n)
// ----------------------------------------------------------------
static const int PDQ_THRESHOLD = 24;

// Insertion sort over iterator range
template<typename It>
void pdq_insertionSort(It begin, It end) {
    for (It i = begin + 1; i != end; ++i) {
        auto val = *i;
        It j = i;
        while (j != begin) {
            ++g_comparisons;
            if (*(j - 1) > val) { *j = *(j - 1); --j; }
            else break;
        }
        *j = val;
    }
}

// Median-of-three pivot selection
template<typename It>
It pdq_medianOfThree(It a, It b, It c) {
    ++g_comparisons; ++g_comparisons;
    if (*a < *b) {
        if (*b < *c) return b;
        return (*a < *c) ? c : a;
    }
    if (*a < *c) return a;
    return (*b < *c) ? c : b;
}

// Heapsort fallback (wraps STL for simplicity)
template<typename It>
void pdq_heapSort(It begin, It end) {
    make_heap(begin, end);
    sort_heap(begin, end);
    // approximate comparison count for heapsort
    long long n = end - begin;
    g_comparisons += (long long)(n * log2((double)n + 1) * 2);
}

template<typename It>
void pdq_impl(It begin, It end, int depthLimit) {
    auto size = end - begin;
    if (size <= PDQ_THRESHOLD) { pdq_insertionSort(begin, end); return; }
    if (depthLimit == 0)       { pdq_heapSort(begin, end);     return; }

    // Pattern detection: check if already sorted
    bool sorted = true;
    for (It i = begin; i != end - 1 && sorted; ++i) {
        ++g_comparisons;
        if (*i > *(i + 1)) sorted = false;
    }
    if (sorted) return;

    // Pivot selection: median-of-three
    It mid      = begin + size / 2;
    It pivotPos = pdq_medianOfThree(begin, mid, end - 1);
    auto pivot  = *pivotPos;
    swap(*pivotPos, *(end - 1));

    // Partition
    It left = begin, right = end - 2;
    while (left <= right) {
        while (left <= right) { ++g_comparisons; if (*left  < pivot) ++left;  else break; }
        while (left <= right) { ++g_comparisons; if (*right > pivot) --right; else break; }
        if (left <= right) swap(*left++, *right--);
    }
    swap(*left, *(end - 1));

    pdq_impl(begin, left, depthLimit - 1);
    pdq_impl(left + 1, end, depthLimit - 1);
}

void pdqSort(vector<int>& arr) {
    int depth = 2 * (int)log2((double)arr.size() + 1);
    pdq_impl(arr.begin(), arr.end(), depth);
}

// ----------------------------------------------------------------
//  C) INTROSORT
//     Industry standard (used in C++ STL).
//     Quicksort → falls back to heapsort if depth exceeded,
//     and insertion sort for tiny sub-arrays.
//     Best: O(n log n)  |  Avg: O(n log n)  |  Worst: O(n log n)
// ----------------------------------------------------------------
void intro_heapify(vector<int>& arr, int n, int root, int base) {
    while (true) {
        int largest = root, l = 2*root+1, r = 2*root+2;
        ++g_comparisons;
        if (l < n && arr[base+l] > arr[base+largest]) largest = l;
        ++g_comparisons;
        if (r < n && arr[base+r] > arr[base+largest]) largest = r;
        if (largest == root) break;
        swap(arr[base+root], arr[base+largest]);
        root = largest;
    }
}

void intro_heapSort(vector<int>& arr, int begin, int end) {
    int n = end - begin;
    for (int i = n/2 - 1; i >= 0; --i) intro_heapify(arr, n, i, begin);
    for (int i = n - 1; i > 0; --i) {
        swap(arr[begin], arr[begin + i]);
        intro_heapify(arr, i, 0, begin);
    }
}

int intro_partition(vector<int>& arr, int low, int high) {
    // Median-of-three pivot
    int mid = low + (high - low) / 2;
    if (arr[mid] < arr[low])  swap(arr[mid], arr[low]);
    if (arr[high] < arr[low]) swap(arr[high], arr[low]);
    if (arr[mid] < arr[high]) swap(arr[mid], arr[high]);
    // arr[high] is now the median
    int pivot = arr[high], i = low - 1;
    for (int j = low; j < high; ++j) {
        ++g_comparisons;
        if (arr[j] <= pivot) swap(arr[++i], arr[j]);
    }
    swap(arr[i+1], arr[high]);
    return i + 1;
}

void intro_impl(vector<int>& arr, int low, int high, int depth) {
    if (high - low < 16) {
        // Insertion sort for small subarrays
        for (int i = low + 1; i <= high; ++i) {
            int key = arr[i]; int j = i - 1;
            while (j >= low) {
                ++g_comparisons;
                if (arr[j] > key) { arr[j+1] = arr[j]; --j; }
                else break;
            }
            arr[j+1] = key;
        }
        return;
    }
    if (depth == 0) { intro_heapSort(arr, low, high + 1); return; }
    int p = intro_partition(arr, low, high);
    intro_impl(arr, low, p - 1, depth - 1);
    intro_impl(arr, p + 1, high, depth - 1);
}

void introSort(vector<int>& arr) {
    if (arr.size() < 2) return;
    int depth = 2 * (int)log2((double)arr.size() + 1);
    intro_impl(arr, 0, (int)arr.size() - 1, depth);
}

// ================================================================
//  PART 3 — SEARCH ALGORITHMS
// ================================================================

// ----------------------------------------------------------------
//  A) BINARY SEARCH — O(log n)
// ----------------------------------------------------------------
int binarySearch(const vector<int>& arr, int target) {
    int lo = 0, hi = (int)arr.size() - 1;
    while (lo <= hi) {
        ++g_comparisons;
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] == target) return mid;
        ++g_comparisons;
        if (arr[mid] < target) lo = mid + 1;
        else                   hi = mid - 1;
    }
    return -1;
}

// ----------------------------------------------------------------
//  B) EXPONENTIAL SEARCH — O(log n)
//     Good for unbounded/infinite arrays; finds range quickly.
// ----------------------------------------------------------------
int exponentialSearch(const vector<int>& arr, int target) {
    int n = (int)arr.size();
    if (n == 0) return -1;
    ++g_comparisons;
    if (arr[0] == target) return 0;

    int i = 1;
    while (i < n) {
        ++g_comparisons;
        if (arr[i] <= target) i <<= 1;   // double i
        else break;
    }
    // Binary search in [i/2, min(i, n-1)]
    int lo = i >> 1, hi = min(i, n - 1);
    while (lo <= hi) {
        ++g_comparisons;
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] == target) return mid;
        ++g_comparisons;
        if (arr[mid] < target) lo = mid + 1;
        else                   hi = mid - 1;
    }
    return -1;
}

// ----------------------------------------------------------------
//  C) SKIP LIST SEARCH — O(log n) expected
//     Probabilistic multi-level linked list.
//     Level probability = 0.5, max 16 levels.
// ----------------------------------------------------------------
static const int SKIP_MAX_LEVEL = 16;
static const float SKIP_PROB    = 0.5f;

struct SkipNode {
    int val;
    vector<SkipNode*> next;
    SkipNode(int v, int lvl) : val(v), next(lvl + 1, nullptr) {}
};

class SkipList {
    int   level_;
    SkipNode* head_;
    mt19937 rng_;

public:
    SkipList() : level_(0), rng_(123) {
        head_ = new SkipNode(INT_MIN, SKIP_MAX_LEVEL);
    }

    ~SkipList() {
        SkipNode* cur = head_;
        while (cur) { SkipNode* nxt = cur->next[0]; delete cur; cur = nxt; }
    }

    int randomLevel() {
        int lvl = 0;
        while ((float)rng_() / rng_.max() < SKIP_PROB && lvl < SKIP_MAX_LEVEL)
            ++lvl;
        return lvl;
    }

    void insert(int val) {
        vector<SkipNode*> update(SKIP_MAX_LEVEL + 1);
        SkipNode* cur = head_;
        for (int i = level_; i >= 0; --i) {
            while (cur->next[i] && cur->next[i]->val < val)
                cur = cur->next[i];
            update[i] = cur;
        }
        int nl = randomLevel();
        if (nl > level_) {
            for (int i = level_ + 1; i <= nl; ++i) update[i] = head_;
            level_ = nl;
        }
        SkipNode* node = new SkipNode(val, nl);
        for (int i = 0; i <= nl; ++i) {
            node->next[i]    = update[i]->next[i];
            update[i]->next[i] = node;
        }
    }

    int search(int val) {
        SkipNode* cur = head_;
        for (int i = level_; i >= 0; --i) {
            while (cur->next[i]) {
                ++g_comparisons;
                if (cur->next[i]->val < val) cur = cur->next[i];
                else break;
            }
        }
        cur = cur->next[0];
        ++g_comparisons;
        return (cur && cur->val == val) ? cur->val : -1;
    }
};

// ================================================================
//  PART 4 — MEASUREMENT HELPERS
// ================================================================

struct SortResult {
    string    name;
    string    dataset;
    double    time_ms;
    long long comparisons;
};

struct SearchResult {
    string name;
    double avg_us;
    double worst_us;
    long long avg_comparisons;
};

/** Run a sort function on a *copy* of data, return metrics. */
SortResult measureSort(
    const string& algName,
    const string& dsName,
    const vector<int>& data,
    const function<void(vector<int>&)>& fn)
{
    vector<int> tmp = data;          // work on a copy
    g_comparisons   = 0;
    auto t0 = high_resolution_clock::now();
    fn(tmp);
    auto t1 = high_resolution_clock::now();
    return { algName, dsName,
             duration<double, milli>(t1 - t0).count(),
             g_comparisons };
}

/** Sanity-check that an array is sorted. */
bool isSorted(const vector<int>& v) {
    for (size_t i = 1; i < v.size(); ++i)
        if (v[i] < v[i-1]) return false;
    return true;
}

// ================================================================
//  MAIN
// ================================================================
int main() {
    const int N        = 1'000'000;
    const int QUERIES  = 1000;

    cout << fixed << setprecision(4);
    cout << "=================================================================\n";
    cout << "  Large-Scale Sorting & Searching Algorithm Evaluation\n";
    cout << "  N = " << N << " | Queries = " << QUERIES << "\n";
    cout << "=================================================================\n\n";

    // ------------------------------------------------------------------
    // Build datasets
    // ------------------------------------------------------------------
    cout << "Generating datasets...\n";
    vector<pair<string, vector<int>>> datasets = {
        { "Random",         generateRandom(N)          },
        { "Nearly Sorted",  generateNearlySorted(N)    },
        { "Reverse Sorted", generateReverseSorted(N)   },
        { "Duplicates",     generateWithDuplicates(N)  }
    };
    cout << "Done.\n\n";

    // ------------------------------------------------------------------
    // SORTING EXPERIMENTS
    // ------------------------------------------------------------------
    cout << "--- SORTING EXPERIMENT ---\n\n";
    cout << left
         << setw(14) << "Algorithm"
         << setw(17) << "Dataset"
         << setw(14) << "Time (ms)"
         << setw(20) << "Comparisons"
         << "Sorted?\n";
    cout << string(75, '-') << "\n";

    ofstream sortCSV("sort_results.csv");
    sortCSV << "Algorithm,Dataset,Time_ms,Comparisons\n";

    vector<function<void(vector<int>&)>> sortFns = { timSort, pdqSort, introSort };
    vector<string> sortNames = { "Timsort", "PDQSort", "IntroSort" };

    for (auto& [dsName, dsData] : datasets) {
        for (int s = 0; s < 3; ++s) {
            SortResult r = measureSort(sortNames[s], dsName, dsData, sortFns[s]);

            // Verify correctness
            vector<int> tmp = dsData;
            sortFns[s](tmp);
            bool ok = isSorted(tmp);

            cout << left
                 << setw(14) << r.name
                 << setw(17) << r.dataset
                 << setw(14) << r.time_ms
                 << setw(20) << r.comparisons
                 << (ok ? "YES" : "NO!") << "\n";

            sortCSV << r.name << "," << r.dataset << ","
                    << r.time_ms << "," << r.comparisons << "\n";
        }
        cout << "\n";
    }

    sortCSV.close();
    cout << "  [sort_results.csv written]\n\n";

    // ------------------------------------------------------------------
    // SEARCHING EXPERIMENTS
    // ------------------------------------------------------------------
    cout << "--- SEARCH EXPERIMENT (sorted Random dataset) ---\n\n";

    // Sort the random dataset
    vector<int> sortedData = datasets[0].second;
    cout << "Sorting dataset for search tests... ";
    timSort(sortedData);
    cout << "Done.\n";

    // Build Skip List
    cout << "Building Skip List (" << N << " nodes)... ";
    SkipList sl;
    for (int x : sortedData) sl.insert(x);
    cout << "Done.\n\n";

    // Generate 1000 query values
    mt19937 qrng(77);
    uniform_int_distribution<int> qdist(1, 10'000'000);
    vector<int> queries(QUERIES);
    for (auto& q : queries) q = qdist(qrng);

    cout << left
         << setw(22) << "Algorithm"
         << setw(18) << "Avg Time (µs)"
         << setw(20) << "Worst Time (µs)"
         << "Avg Comparisons\n";
    cout << string(76, '-') << "\n";

    ofstream searchCSV("search_results.csv");
    searchCSV << "Algorithm,Avg_us,Worst_us,Avg_Comparisons\n";

    // Helper lambda to benchmark a search function
    auto benchSearch = [&](const string& name, auto fn) {
        double total = 0.0, worst = 0.0;
        long long totalComp = 0;
        for (int q : queries) {
            g_comparisons = 0;
            auto t0 = high_resolution_clock::now();
            fn(q);
            auto t1 = high_resolution_clock::now();
            double us = duration<double, micro>(t1 - t0).count();
            total     += us;
            if (us > worst) worst = us;
            totalComp += g_comparisons;
        }
        double avg = total / QUERIES;
        long long avgC = totalComp / QUERIES;
        cout << left
             << setw(22) << name
             << setw(18) << avg
             << setw(20) << worst
             << avgC << "\n";
        searchCSV << name << "," << avg << "," << worst << "," << avgC << "\n";
    };

    benchSearch("Binary Search",
        [&](int q){ return binarySearch(sortedData, q); });
    benchSearch("Exponential Search",
        [&](int q){ return exponentialSearch(sortedData, q); });
    benchSearch("Skip List",
        [&](int q){ return sl.search(q); });

    searchCSV.close();
    cout << "\n  [search_results.csv written]\n\n";

    cout << "=================================================================\n";
    cout << "  All experiments complete. CSV files ready for plotting.\n";
    cout << "=================================================================\n";
    return 0;
}
