"""
visualize_results.py
====================
Generates all performance graphs for the algorithm project report.
Run AFTER executing the C++ binary (which produces sort_results.csv and search_results.csv).

Requirements:
    pip install matplotlib pandas numpy
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import os

# ── Style ──────────────────────────────────────────────────────────────
plt.rcParams.update({
    "figure.dpi": 150,
    "font.family": "DejaVu Sans",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.35,
})

SORT_COLORS  = {"Timsort": "#2196F3", "PDQSort": "#4CAF50", "IntroSort": "#FF5722"}
SEARCH_COLORS = {"Binary Search": "#9C27B0", "Exponential Search": "#FF9800", "Skip List": "#00BCD4"}
OUTPUT_DIR = "graphs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def save(fig, name):
    path = os.path.join(OUTPUT_DIR, name)
    fig.savefig(path, bbox_inches="tight")
    print(f"  Saved → {path}")
    plt.close(fig)

# ── Load data ─────────────────────────────────────────────────────────
sort_df   = pd.read_csv("sort_results.csv")
search_df = pd.read_csv("search_results.csv")

datasets = sort_df["Dataset"].unique()
algs     = sort_df["Algorithm"].unique()

# ══════════════════════════════════════════════════════════════════════
# FIGURE 1 — Sorting Time: grouped bar chart per dataset
# ══════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(10, 5))
x      = np.arange(len(datasets))
width  = 0.25

for i, alg in enumerate(algs):
    vals = [sort_df[(sort_df["Algorithm"] == alg) & (sort_df["Dataset"] == ds)]["Time_ms"].values[0]
            for ds in datasets]
    bars = ax.bar(x + i * width, vals, width, label=alg, color=SORT_COLORS[alg], alpha=0.88)
    ax.bar_label(bars, fmt="%.1f", padding=3, fontsize=7)

ax.set_xticks(x + width)
ax.set_xticklabels(datasets, fontsize=10)
ax.set_ylabel("Execution Time (ms)")
ax.set_title("Sorting Algorithm Comparison — Execution Time (N = 1,000,000)", fontweight="bold")
ax.legend()
fig.tight_layout()
save(fig, "fig1_sort_time.png")

# ══════════════════════════════════════════════════════════════════════
# FIGURE 2 — Sorting Comparisons: grouped bar chart
# ══════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(10, 5))

for i, alg in enumerate(algs):
    vals = [sort_df[(sort_df["Algorithm"] == alg) & (sort_df["Dataset"] == ds)]["Comparisons"].values[0]
            for ds in datasets]
    bars = ax.bar(x + i * width, vals, width, label=alg, color=SORT_COLORS[alg], alpha=0.88)

ax.set_xticks(x + width)
ax.set_xticklabels(datasets, fontsize=10)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v/1e6:.1f}M"))
ax.set_ylabel("Number of Comparisons (millions)")
ax.set_title("Sorting Algorithm Comparison — Number of Comparisons", fontweight="bold")
ax.legend()
fig.tight_layout()
save(fig, "fig2_sort_comparisons.png")

# ══════════════════════════════════════════════════════════════════════
# FIGURE 3 — Theoretical complexity overlay (simulated sizes)
# ══════════════════════════════════════════════════════════════════════
sizes = np.array([1000, 10_000, 100_000, 500_000, 1_000_000])
fig, ax = plt.subplots(figsize=(9, 5))

# Use actual times from Random dataset as reference at N=1M
actual_1M = {
    alg: sort_df[(sort_df["Algorithm"] == alg) & (sort_df["Dataset"] == "Random")]["Time_ms"].values[0]
    for alg in algs
}
ref = 1_000_000

for alg in algs:
    base = actual_1M[alg]
    # Scale by n log n ratio
    pred = np.array([base * (s * np.log2(s + 1)) / (ref * np.log2(ref + 1)) for s in sizes])
    ax.plot(sizes, pred, "o--", label=alg, color=SORT_COLORS[alg], linewidth=2, markersize=6)

ax.set_xscale("log")
ax.set_xlabel("Input Size (n)")
ax.set_ylabel("Estimated Time (ms)")
ax.set_title("Projected Performance vs Input Size (O(n log n) scaling)", fontweight="bold")
ax.legend()
fig.tight_layout()
save(fig, "fig3_sort_scaling.png")

# ══════════════════════════════════════════════════════════════════════
# FIGURE 4 — Search: Average time (bar)
# ══════════════════════════════════════════════════════════════════════
fig, axes = plt.subplots(1, 2, figsize=(11, 5))

search_algs = search_df["Algorithm"].tolist()
colors = [SEARCH_COLORS[a] for a in search_algs]

# Avg time
axes[0].bar(search_algs, search_df["Avg_us"], color=colors, alpha=0.88)
for idx, (alg, row) in enumerate(search_df.iterrows()):
    axes[0].text(idx, row["Avg_us"] + 0.002, f'{row["Avg_us"]:.4f}', ha='center', fontsize=9)
axes[0].set_ylabel("Avg Query Time (µs)")
axes[0].set_title("Search: Average Query Time", fontweight="bold")

# Worst case time
axes[1].bar(search_algs, search_df["Worst_us"], color=colors, alpha=0.88)
for idx, (alg, row) in enumerate(search_df.iterrows()):
    axes[1].text(idx, row["Worst_us"] + 0.05, f'{row["Worst_us"]:.3f}', ha='center', fontsize=9)
axes[1].set_ylabel("Worst-Case Query Time (µs)")
axes[1].set_title("Search: Worst-Case Query Time", fontweight="bold")

for ax in axes:
    ax.tick_params(axis='x', rotation=15)

fig.suptitle("Search Algorithm Comparison (1,000 Queries on 1M Elements)", fontweight="bold", y=1.02)
fig.tight_layout()
save(fig, "fig4_search_time.png")

# ══════════════════════════════════════════════════════════════════════
# FIGURE 5 — Search: Average comparisons (horizontal bar)
# ══════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(8, 4))
ax.barh(search_df["Algorithm"], search_df["Avg_Comparisons"], color=colors, alpha=0.88)
ax.set_xlabel("Average Comparisons per Query")
ax.set_title("Search Algorithm — Average Comparisons (log₂(1,000,000) ≈ 20)", fontweight="bold")
ax.axvline(20, linestyle="--", color="red", alpha=0.6, label="Theoretical O(log n)")
ax.legend()
fig.tight_layout()
save(fig, "fig5_search_comparisons.png")

# ══════════════════════════════════════════════════════════════════════
# FIGURE 6 — Summary heatmap: normalised time across datasets
# ══════════════════════════════════════════════════════════════════════
pivot = sort_df.pivot(index="Algorithm", columns="Dataset", values="Time_ms")
norm  = pivot.div(pivot.max(axis=1), axis=0)   # row-normalise

fig, ax = plt.subplots(figsize=(9, 3.5))
im = ax.imshow(norm.values, cmap="RdYlGn_r", aspect="auto", vmin=0, vmax=1)
ax.set_xticks(range(len(pivot.columns))); ax.set_xticklabels(pivot.columns, fontsize=10)
ax.set_yticks(range(len(pivot.index)));   ax.set_yticklabels(pivot.index, fontsize=11, fontweight="bold")
for i in range(len(pivot.index)):
    for j in range(len(pivot.columns)):
        ax.text(j, i, f"{pivot.values[i,j]:.1f}ms", ha="center", va="center", fontsize=9)
plt.colorbar(im, ax=ax, fraction=0.04, label="Relative Time (1 = slowest)")
ax.set_title("Heatmap: Sorting Time Across Dataset Variants (ms)", fontweight="bold")
fig.tight_layout()
save(fig, "fig6_heatmap.png")

print(f"\nAll {len(os.listdir(OUTPUT_DIR))} graphs saved to ./{OUTPUT_DIR}/")
